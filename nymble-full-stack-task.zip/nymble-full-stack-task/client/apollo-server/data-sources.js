export default function() {
  return {};
}
