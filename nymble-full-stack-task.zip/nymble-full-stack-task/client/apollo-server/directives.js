export default {
  // Schema directives
  // https://www.apollographql.com/docs/graphql-tools/schema-directives.html
}
