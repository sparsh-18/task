<template>
    <div>
        <div class="movie" v-for="m in movies" :key="m.id">
             <h2>{{m.title}}</h2>
             <h3>Genre: </h3>
             <div v-for="g in m.genre_ids" :key="g.id">
                 <div v-for="genre in genres" :key="genre.id">
                     <span v-if="g === genre.id ">{{genre.name}}</span>
                 </div>
             </div>
             <h3>Release Date: {{m.release_date}}</h3>
             <h3>Popularity: {{m.popularity}}</h3>
             <router-link :to="{name: 'Movie', params: {m,genres}}">Know More</router-link>
        </div>
           
    </div>
   
</template>

<style scoped>
.movie {
    border: 1px solid;
    padding: 10px;
    margin-bottom: 25px ;
}
</style>

<script>
import gql from "graphql-tag"
    
export default {
    
    name: 'homepage',
   
    apollo: {
        movies: gql `
        query {
            movies{
                id
                title
                release_date
                popularity
                overview
                vote_average
                vote_count
                adult
                genre_ids
            }
        }
        `,
        genres : gql`
        query {
            genres{
                id
                name
            }
        }
        `
    }
}
</script>