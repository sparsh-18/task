<template>
  <div class="home">
    
    <homepage msg="Welcome to Your Vue.js + TypeScript App"/>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
//import homepage from '@/components/homepage.vue'; // @ is an alias to /src
import Homepage from '../components/homepage.vue';

export default Vue.extend({
  name: 'Home',
  components: {
    
    Homepage,
  },
});
</script>
