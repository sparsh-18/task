<template>
  <div class="movie">
    <h1> Title: {{m.title}}</h1>
    <h3>Released on: {{m.release_date}}</h3>
    <h3>Popularity: {{m.popularity}}</h3>
    <h3>Average Vote: {{m.vote_average}}</h3>
    <h3>Vote Count: {{m.vote_count}}</h3>
    <h3>Adult: <span v-if="m.adult">Yes</span> <span v-else>No</span></h3>
    <h3>Genre:</h3>
    <div v-for="g in m.genre_ids" :key="g.id">
        <div v-for="genre in genres" :key="genre.id">
             <span v-if="g === genre.id ">{{genre.name}}</span>
        </div>
    </div>
    <br>
    
    <h1>Overview:</h1>
    <p style="padding-left: 20%; padding-right: 20%" >{{m.overview}}</p>

  </div>
</template>

<script lang="ts">
import Vue from 'vue';
//import homepage from '@/components/homepage.vue'; // @ is an alias to /src

export default Vue.extend({
  name: 'Movie',
 
  props: ['m','genres'],
 
});
</script>
