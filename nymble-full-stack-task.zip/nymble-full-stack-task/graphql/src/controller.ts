import { movies } from "./db";
import { Movie } from "./types";

export function getMovies(search?: string): Movie[] {
    // TODO
    return movies
}